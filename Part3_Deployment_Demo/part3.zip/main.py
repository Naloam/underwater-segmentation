"""
主入口脚本

提供统一的命令行接口。
"""

import sys
import argparse
from pathlib import Path

# 添加项目路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / '05_Shared'))
sys.path.insert(0, str(project_root / '04_Demo/src'))
sys.path.insert(0, str(project_root / '01_DataVisualization/src'))
sys.path.insert(0, str(project_root / '02_ModelOptimization/src'))
sys.path.insert(0, str(project_root / '03_EmbeddedDeployment/src'))


def run_demo():
    """启动PyQt5 Demo"""
    from src.ui.main_window import MainWindow
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtCore import Qt

    app = QApplication(sys.argv)
    app.setApplicationName("水下图像增强+全景分割系统")

    window = MainWindow()
    window.show()

    sys.exit(app.exec_())


def generate_visualizations():
    """生成可视化对比图"""
    from visual_comparison import VisualComparisonGenerator

    project_root = Path('d:/myProjects/大创(1)')
    output_dir = project_root / 'Part3_Deployment_Demo' / '01_DataVisualization' / 'output' / 'comparisons'

    # 处理SUIM数据集
    suim_path = project_root / 'SUIM_Processed'
    if suim_path.exists():
        print("处理SUIM数据集...")
        generator = VisualComparisonGenerator(suim_path)
        generator.batch_generate(output_dir / 'SUIM', num_samples=10)
        print(f"SUIM对比图已保存到: {output_dir / 'SUIM'}")


def generate_report():
    """生成实验报告"""
    from report_generator import generate_full_report

    output_dir = Path('d:/myProjects/大创(1)/Part3_Deployment_Demo/01_DataVisualization/output')
    generate_full_report(output_dir)
    print(f"实验报告已保存到: {output_dir / 'reports'}")


def run_deployment_simulation():
    """运行部署模拟"""
    from deployment_simulator import JetsonSimulator

    simulator = JetsonSimulator()

    models = [
        {
            "name": "Mask2Former_FP16",
            "params": 200,
            "flops": 100,
            "input_size": (3, 512, 512)
        },
        {
            "name": "Lightweight_FP16",
            "params": 5,
            "flops": 3,
            "input_size": (3, 512, 512)
        }
    ]

    output_dir = Path('d:/myProjects/大创(1)/Part3_Deployment_Demo/03_EmbeddedDeployment/simulation_results')
    simulator.run_simulation_suite(models, output_dir)


def run_tests():
    """运行测试"""
    import subprocess

    test_files = [
        '04_Demo/tests/demo_tests.py',
    ]

    for test_file in test_files:
        test_path = project_root / test_file
        if test_path.exists():
            print(f"\n运行测试: {test_file}")
            result = subprocess.run([sys.executable, str(test_path)], cwd=project_root)
            if result.returncode != 0:
                print(f"测试失败: {test_file}")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='水下图像增强+全景分割系统')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')

    # Demo命令
    subparsers.add_parser('demo', help='启动PyQt5 Demo')

    # 可视化命令
    subparsers.add_parser('visualize', help='生成可视化对比图')
    subparsers.add_parser('report', help='生成实验报告')

    # 部署命令
    subparsers.add_parser('simulate', help='运行部署模拟')

    # 测试命令
    subparsers.add_parser('test', help='运行测试')

    # 解析参数
    args = parser.parse_args()

    # 执行命令
    if args.command == 'demo':
        run_demo()
    elif args.command == 'visualize':
        generate_visualizations()
    elif args.command == 'report':
        generate_report()
    elif args.command == 'simulate':
        run_deployment_simulation()
    elif args.command == 'test':
        run_tests()
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
